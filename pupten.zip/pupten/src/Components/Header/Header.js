import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import logo from "../../Images/logo.svg";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  title: {
    flexGrow: 0,
  },
  navBar: {
    backgroundColor: "#588b8b",
  },
  btn: {
    backgroundColor: "#ffffff",
    color: "#588b8b",
    borderRadius: "1rem",
    fontWeight: 700,
  },
  options: {
    flexGrow: 2,
    display: "inline-flex",
    justifyContent: "flex-end",
  },
  option: {
    margin: "10px 30px",
    color: "#ffffff",
    fontWeight: 700,
    "&:hover": {
      cursor: "pointer",
      opacity: "0.5",
    },
  },
  bookOption: {
    margin: "30px 0px",
  },
}));

function Header() {
  const classes = useStyles();
  return (
    <React.Fragment>
      <AppBar position="static" className={classes.navBar}>
        <Toolbar>
          <Typography variant="h6" className={classes.title}>
            <img src={logo} alt="Pupten" />
          </Typography>
          <Typography variant="h6" className={classes.options}>
            <Typography className={classes.option}>About Us</Typography>
            <Typography className={classes.option}>Product</Typography>
            <Typography className={classes.option}>Pricing</Typography>
            <Typography className={classes.option}>Blog</Typography>
            <Typography className={classes.option}>Book a Demo</Typography>
            <Typography className={classes.option}>Login</Typography>
            <Button color="inherit" className={classes.btn}>
              Sign Up
            </Button>
          </Typography>
        </Toolbar>
        <Typography variant="h3" className={classes.bookOption}>
          Find and Book a Vet
        </Typography>
      </AppBar>
    </React.Fragment>
  );
}

export default Header;
